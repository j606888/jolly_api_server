# jolly_api_server

[document](https://www.serverless.com/blog/serverless-express-rest-api)

[lambda](https://ap-southeast-1.console.aws.amazon.com/lambda/home?region=ap-southeast-1#/functions/jolly-api-server-dev-app?tab=monitoring)

[cloudwatch](https://ap-southeast-1.console.aws.amazon.com/cloudwatch/home?region=ap-southeast-1#logsV2:log-groups/log-group/$252Faws$252Flambda$252Fjolly-api-server-dev-app)