const serverless = require('serverless-http')
const express = require('express')
const app = express()

app.get('/', (req, res) => {
  // const POSTGRES_PASSWORD = process.env.POSTGRES_PASSWORD
  // res.send("Hello World", POSTGRES_PASSWORD)
  res.send("Hello world")
})

module.exports.handler = serverless(app)

// app.listen(3000, () => {
//   console.log("running on 3000")
// })